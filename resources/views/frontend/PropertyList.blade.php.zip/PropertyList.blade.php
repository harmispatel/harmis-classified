@extends('frontend.common.layout')


@section('content')
<section class="property-main page-title-bg">
    <div class="container">
        <div class="container-fluid">
            <div class="card">
                <div class="row">
                    <div class="col-md-2">
                        <div class="list-op">
                            <select onchange="getPropertyList('filterClick');" name="category" id="selectCategory" class="form-select">
                                <option value="0">{{ __('Other Options') }}</option>
                                @forelse ($category as $categoryName)
                                    <option value="{{$categoryName->id}}">{{__($categoryName->name)}}</option>
                                @empty
                                    <div class="post-wrap col-lg-12 col-md-12 text-center">
                                        <span class="text-secondary">{{__('labels.empty_properties')}}</span>
                                    </div>
                                @endforelse
                            </select>
                            {{-- <h3>{{ __('Other Options') }}</h3>
                            <div class="list-inr-op">
                                @forelse ($category as $categoryName)
                                    <div class="custom-control custom-checkbox op-inr">
                                        <input name="category" onclick="getPropertyList('filterClick');" type="radio" value="{{$categoryName->id}}" class="custom-control-input" id="customRadio04">
                                        <label class="custom-control-label" for="customCheck04">{{__($categoryName->name)}}</label>
                                    </div>
                                @empty
                                    <div class="post-wrap col-lg-12 col-md-12 text-center">
                                        <span class="text-secondary">{{__('labels.empty_properties')}}</span>
                                    </div>
                                @endforelse
                            </div>
                            <button class="btn btn-primary" onclick="clearFilter('category')">{{ __('Clear') }}</button> --}}
                        </div>

                    </div>
                    <div class="col-md-2">
                        <div class="list-op">
                            <select onchange="getPropertyList('filterClick');" name="propertyType" id="propertyType" class="form-select">
                                <option value=""  class="custom-control-input customCheck05" checked><h3>{{ __('Other Options') }}</h3></option>
                                <option value=""  class="custom-control-input customCheck05" checked>{{ __('For Both') }}</option>
                                <option value="1" class="custom-control-input customCheck05">{{ __('For Rent') }}</option>
                                <option value="2" class="custom-control-input customCheck05">{{ __('For Sales') }}</option>
                            </select>



                            {{-- <h3>{{ __('Other Options') }}</h3>
                            <div class="list-inr-op">
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="propertyType" onclick="getPropertyList('filterClick');" value="" type="radio" class="custom-control-input customCheck05" checked/>
                                    <label class="custom-control-label" for="customCheck05">{{ __('For Both') }}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="propertyType" onclick="getPropertyList('filterClick');" value="1" type="radio" class="custom-control-input customCheck05">
                                    <label class="custom-control-label" for="customCheck05">{{ __('For Rent') }}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="propertyType" onclick="getPropertyList('filterClick');" value="2" type="radio" class="custom-control-input customCheck05">
                                    <label class="custom-control-label" for="customCheck05">{{ __('For Sales') }}</label>
                                </div>
                            </div> --}}
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="list-op">

                            <select onchange="getPropertyList('filterClick');" name="property_condition" id="propertyCondition" class="form-select">
                                <option value="" class="custom-control-input"><h3>{{ __('Other Options') }}</h3></option>
                                <option value="1" class="custom-control-input">{{ __('Used') }}</option>
                                <option value="2" class="custom-control-input">{{ __('New') }}</option>
                                <option value="3" class="custom-control-input">{{ __('Furnished') }}</option>
                                <option value="4" class="custom-control-input">{{ __('Unfurnished') }}</option>
                            </select>


                            {{-- <h3>{{ __('Other Options') }}</h3>
                            <div class="list-inr-op">
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="property_condition" onclick="getPropertyList('filterClick');" value="1" type="radio" class="custom-control-input" id="customRadio1">
                                    <label class="custom-control-label" for="customCheck1">{{ __('Used') }}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="property_condition" onclick="getPropertyList('filterClick');" value="2" type="radio" class="custom-control-input" id="customRadio2">
                                    <label class="custom-control-label" for="customCheck2">{{ __('New') }}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="property_condition" onclick="getPropertyList('filterClick');" value="3" type="radio" class="custom-control-input" id="customRadio3">
                                    <label class="custom-control-label" for="customCheck3">{{ __('Furnished') }}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="property_condition" onclick="getPropertyList('filterClick');" value="4" type="radio" class="custom-control-input" id="customRadio4">
                                    <label class="custom-control-label" for="customCheck4">{{ __('Unfurnished') }}</label>
                                </div>
                            </div> --}}
                            {{-- <button class="btn btn-primary" onclick="clearFilter('property_condition')">{{ __('Clear') }}</button> --}}
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="list-op">
                            <select onchange="getPropertyList('filterClick');" name="floor" id="floor" class="form-select">
                                <option value="" class="custom-control-input"><h3>{{ __('Floor') }}</h3></option>
                                <option value="1" class="custom-control-input">{{ __('Settlement') }}</option>
                                <option value="2" class="custom-control-input">{{ __('Semi Ground') }}</option>
                                <option value="3" class="custom-control-input">{{ __('My Land') }}</option>
                                <option value="4" class="custom-control-input">{{ __('The First') }}</option>
                                <option value="5" class="custom-control-input">{{__('The Second')}}</option>
                                <option value="6" class="custom-control-input">{{__('The Third')}}</option>
                                <option value="7" class="custom-control-input">{{__('Fourth +')}}</option>
                            </select>

                            {{-- <h3>{{ __('Floor') }}</h3>
                            <div class="list-inr-op">
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="floor" type="radio" value="1" onclick="getPropertyList('filterClick');" class="custom-control-input" id="customCheck6">
                                    <label class="custom-control-label" for="customCheck6">{{ __('Settlement') }}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="floor" type="radio" value="2" onclick="getPropertyList('filterClick');"  class="custom-control-input" id="customCheck7">
                                    <label class="custom-control-label" for="customCheck7">{{ __('Semi Ground') }}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="floor" type="radio" value="3" onclick="getPropertyList('filterClick');" class="custom-control-input" id="customCheck8">
                                    <label class="custom-control-label" for="customCheck8">{{ __('My Land') }}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="floor" type="radio" value="4" onclick="getPropertyList('filterClick');" class="custom-control-input" id="customCheck9">
                                    <label class="custom-control-label" for="customCheck9">{{ __('The First') }}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="floor" type="radio" value="5" onclick="getPropertyList('filterClick');" class="custom-control-input" id="customCheck10">
                                    <label class="custom-control-label" for="customCheck10">{{__('The Second')}}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="floor" type="radio" value="6" onclick="getPropertyList('filterClick');" class="custom-control-input" id="customCheck11">
                                    <label class="custom-control-label" for="customCheck11">{{__('The Third')}}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="floor" type="radio" value="7" onclick="getPropertyList('filterClick');" class="custom-control-input" id="customCheck12">
                                    <label class="custom-control-label" for="customCheck12">{{__('Fourth +')}}</label>
                                </div>
                            </div>
                            <button class="btn btn-primary" onclick="clearFilter('floor')">{{__('Clear')}}</button> --}}
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="list-op">
                            <select onchange="getPropertyList('filterClick');" name="bedroom" id="bedroom" class="form-select">
                                <option value="" class="badge nu-inr-st bedroom"><h3>{{ __('Number Of BedRooms') }}</h3></option>
                                <option value="1" class="badge nu-inr-st bedroom">1</option>
                                <option value="2" class="badge nu-inr-st bedroom">2</option>
                                <option value="3" class="badge nu-inr-st bedroom">3</option>
                                <option value="4" class="badge nu-inr-st bedroom">4</option>
                                <option value="5+" class="badge nu-inr-st bedroom">5+</option>
                            </select>

                            {{-- <div class="bulid-info">
                                <h3>{{ __('Number Of BedRooms') }}</h3>
                                <div class="nu-inr">
                                    <input type="hidden" name="bedroom" class="badge nu-inr-st bedroom" value="0" />
                                    <p style="color:black" class="badge nu-inr-st bedroom" class="bedroom">1</p>
                                    <p style="color:black" class="badge nu-inr-st bedroom" class="bedroom">2</p>
                                    <p style="color:black" class="badge nu-inr-st bedroom" class="bedroom">3</p>
                                    <p style="color:black" class="badge nu-inr-st bedroom" class="bedroom">4</p>
                                    <p style="color:black" class="badge nu-inr-st bedroom" class="bedroom">5+</p>
                                </div>
                                <div style="margin-top: 182px ">
                                    <button class="btn btn-primary" onclick="clearBedroomFilter('bedroom')">{{ __('Clear') }}</button>
                                </div>
                            </div> --}}
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="list-op">
                            <div class="pri-range">
                                <h3>{{ __('Price') }}</h3>
                                <form>
                                    <div class="form-group">
                                        <label for="formControlRange"></label>
                                        <span style="font-weight: bold;"></span>
                                        <input style="border: none;background:none; font-weight: bold;" type="text"
                                            id="textInput" value="{{$propertyMaxPrice}}">
                                        <input type="range" min="{{ $propertyMinPrice }}"
                                            max="{{ $propertyMaxPrice }}" name="priceRange" value="{{ $propertyMaxPrice }}"
                                            onchange="getPropertyList('filterClick')" class="form-control-range"
                                            id="formControlRange">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <div class="row" style="justify-content: center;">
                <div class="col-12 ajax-load text-center d-none">
                    <p><img src="{{asset('img/loader.png')}}">Load More Post...</p>
                </div>
            </div>
        </div>
        {{-- <div class="page-title">
            <h2>{{__('PROPERTIES PAGE')}}</h2>
            <ol class="breadcrumb">
                <li><a href="#">{{__('HOME')}}</a></li>
                <li class="active"><a href="">{{__('PROPERTY')}}</a></li>
            </ol>
        </div> --}}
    </div>
</section>
    <section class="property_fea">
        <div class="container-fluid">
            <div class="card">
                <div class="row">
                    <div class="col-md-2">
                        <div class="list-op">
                            <select onchange="getPropertyList('filterClick');" name="category" id="selectCategory" class="form-select">
                                <option value="0">{{ __('Other Options') }}</option>
                                @forelse ($category as $categoryName)
                                    <option value="{{$categoryName->id}}">{{__($categoryName->name)}}</option>
                                @empty
                                    <div class="post-wrap col-lg-12 col-md-12 text-center">
                                        <span class="text-secondary">{{__('labels.empty_properties')}}</span>
                                    </div>
                                @endforelse
                            </select>
                            {{-- <h3>{{ __('Other Options') }}</h3>
                            <div class="list-inr-op">
                                @forelse ($category as $categoryName)
                                    <div class="custom-control custom-checkbox op-inr">
                                        <input name="category" onclick="getPropertyList('filterClick');" type="radio" value="{{$categoryName->id}}" class="custom-control-input" id="customRadio04">
                                        <label class="custom-control-label" for="customCheck04">{{__($categoryName->name)}}</label>
                                    </div>
                                @empty
                                    <div class="post-wrap col-lg-12 col-md-12 text-center">
                                        <span class="text-secondary">{{__('labels.empty_properties')}}</span>
                                    </div>
                                @endforelse
                            </div>
                            <button class="btn btn-primary" onclick="clearFilter('category')">{{ __('Clear') }}</button> --}}
                        </div>

                    </div>
                    <div class="col-md-2">
                        <div class="list-op">
                            <select onchange="getPropertyList('filterClick');" name="propertyType" id="propertyType" class="form-select">
                                <option value=""  class="custom-control-input customCheck05" checked><h3>{{ __('Other Options') }}</h3></option>
                                <option value=""  class="custom-control-input customCheck05" checked>{{ __('For Both') }}</option>
                                <option value="1" class="custom-control-input customCheck05">{{ __('For Rent') }}</option>
                                <option value="2" class="custom-control-input customCheck05">{{ __('For Sales') }}</option>
                            </select>



                            {{-- <h3>{{ __('Other Options') }}</h3>
                            <div class="list-inr-op">
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="propertyType" onclick="getPropertyList('filterClick');" value="" type="radio" class="custom-control-input customCheck05" checked/>
                                    <label class="custom-control-label" for="customCheck05">{{ __('For Both') }}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="propertyType" onclick="getPropertyList('filterClick');" value="1" type="radio" class="custom-control-input customCheck05">
                                    <label class="custom-control-label" for="customCheck05">{{ __('For Rent') }}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="propertyType" onclick="getPropertyList('filterClick');" value="2" type="radio" class="custom-control-input customCheck05">
                                    <label class="custom-control-label" for="customCheck05">{{ __('For Sales') }}</label>
                                </div>
                            </div> --}}
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="list-op">

                            <select onchange="getPropertyList('filterClick');" name="property_condition" id="propertyCondition" class="form-select">
                                <option value="" class="custom-control-input"><h3>{{ __('Other Options') }}</h3></option>
                                <option value="1" class="custom-control-input">{{ __('Used') }}</option>
                                <option value="2" class="custom-control-input">{{ __('New') }}</option>
                                <option value="3" class="custom-control-input">{{ __('Furnished') }}</option>
                                <option value="4" class="custom-control-input">{{ __('Unfurnished') }}</option>
                            </select>


                            {{-- <h3>{{ __('Other Options') }}</h3>
                            <div class="list-inr-op">
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="property_condition" onclick="getPropertyList('filterClick');" value="1" type="radio" class="custom-control-input" id="customRadio1">
                                    <label class="custom-control-label" for="customCheck1">{{ __('Used') }}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="property_condition" onclick="getPropertyList('filterClick');" value="2" type="radio" class="custom-control-input" id="customRadio2">
                                    <label class="custom-control-label" for="customCheck2">{{ __('New') }}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="property_condition" onclick="getPropertyList('filterClick');" value="3" type="radio" class="custom-control-input" id="customRadio3">
                                    <label class="custom-control-label" for="customCheck3">{{ __('Furnished') }}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="property_condition" onclick="getPropertyList('filterClick');" value="4" type="radio" class="custom-control-input" id="customRadio4">
                                    <label class="custom-control-label" for="customCheck4">{{ __('Unfurnished') }}</label>
                                </div>
                            </div> --}}
                            {{-- <button class="btn btn-primary" onclick="clearFilter('property_condition')">{{ __('Clear') }}</button> --}}
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="list-op">
                            <select onchange="getPropertyList('filterClick');" name="floor" id="floor" class="form-select">
                                <option value="" class="custom-control-input"><h3>{{ __('Floor') }}</h3></option>
                                <option value="1" class="custom-control-input">{{ __('Settlement') }}</option>
                                <option value="2" class="custom-control-input">{{ __('Semi Ground') }}</option>
                                <option value="3" class="custom-control-input">{{ __('My Land') }}</option>
                                <option value="4" class="custom-control-input">{{ __('The First') }}</option>
                                <option value="5" class="custom-control-input">{{__('The Second')}}</option>
                                <option value="6" class="custom-control-input">{{__('The Third')}}</option>
                                <option value="7" class="custom-control-input">{{__('Fourth +')}}</option>
                            </select>

                            {{-- <h3>{{ __('Floor') }}</h3>
                            <div class="list-inr-op">
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="floor" type="radio" value="1" onclick="getPropertyList('filterClick');" class="custom-control-input" id="customCheck6">
                                    <label class="custom-control-label" for="customCheck6">{{ __('Settlement') }}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="floor" type="radio" value="2" onclick="getPropertyList('filterClick');"  class="custom-control-input" id="customCheck7">
                                    <label class="custom-control-label" for="customCheck7">{{ __('Semi Ground') }}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="floor" type="radio" value="3" onclick="getPropertyList('filterClick');" class="custom-control-input" id="customCheck8">
                                    <label class="custom-control-label" for="customCheck8">{{ __('My Land') }}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="floor" type="radio" value="4" onclick="getPropertyList('filterClick');" class="custom-control-input" id="customCheck9">
                                    <label class="custom-control-label" for="customCheck9">{{ __('The First') }}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="floor" type="radio" value="5" onclick="getPropertyList('filterClick');" class="custom-control-input" id="customCheck10">
                                    <label class="custom-control-label" for="customCheck10">{{__('The Second')}}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="floor" type="radio" value="6" onclick="getPropertyList('filterClick');" class="custom-control-input" id="customCheck11">
                                    <label class="custom-control-label" for="customCheck11">{{__('The Third')}}</label>
                                </div>
                                <div class="custom-control custom-checkbox op-inr">
                                    <input name="floor" type="radio" value="7" onclick="getPropertyList('filterClick');" class="custom-control-input" id="customCheck12">
                                    <label class="custom-control-label" for="customCheck12">{{__('Fourth +')}}</label>
                                </div>
                            </div>
                            <button class="btn btn-primary" onclick="clearFilter('floor')">{{__('Clear')}}</button> --}}
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="list-op">
                            <select onchange="getPropertyList('filterClick');" name="bedroom" id="bedroom" class="form-select">
                                <option value="" class="badge nu-inr-st bedroom"><h3>{{ __('Number Of BedRooms') }}</h3></option>
                                <option value="1" class="badge nu-inr-st bedroom">1</option>
                                <option value="2" class="badge nu-inr-st bedroom">2</option>
                                <option value="3" class="badge nu-inr-st bedroom">3</option>
                                <option value="4" class="badge nu-inr-st bedroom">4</option>
                                <option value="5+" class="badge nu-inr-st bedroom">5+</option>
                            </select>

                            {{-- <div class="bulid-info">
                                <h3>{{ __('Number Of BedRooms') }}</h3>
                                <div class="nu-inr">
                                    <input type="hidden" name="bedroom" class="badge nu-inr-st bedroom" value="0" />
                                    <p style="color:black" class="badge nu-inr-st bedroom" class="bedroom">1</p>
                                    <p style="color:black" class="badge nu-inr-st bedroom" class="bedroom">2</p>
                                    <p style="color:black" class="badge nu-inr-st bedroom" class="bedroom">3</p>
                                    <p style="color:black" class="badge nu-inr-st bedroom" class="bedroom">4</p>
                                    <p style="color:black" class="badge nu-inr-st bedroom" class="bedroom">5+</p>
                                </div>
                                <div style="margin-top: 182px ">
                                    <button class="btn btn-primary" onclick="clearBedroomFilter('bedroom')">{{ __('Clear') }}</button>
                                </div>
                            </div> --}}
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="list-op">
                            <div class="pri-range">
                                <h3>{{ __('Price') }}</h3>
                                <form>
                                    <div class="form-group">
                                        <label for="formControlRange"></label>
                                        <span style="font-weight: bold;"></span>
                                        <input style="border: none;background:none; font-weight: bold;" type="text"
                                            id="textInput" value="{{$propertyMaxPrice}}">
                                        <input type="range" min="{{ $propertyMinPrice }}"
                                            max="{{ $propertyMaxPrice }}" name="priceRange" value="{{ $propertyMaxPrice }}"
                                            onchange="getPropertyList('filterClick')" class="form-control-range"
                                            id="formControlRange">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <div class="row" style="justify-content: center;">
                <div class="col-12 ajax-load text-center d-none">
                    <p><img src="{{asset('img/loader.png')}}">Load More Post...</p>
                </div>
            </div>
        </div>
        <div class="col-md-2">
                <input id="search" type="text" name="search" required/>
                <button onclick="getPropertyList('filterClick')" type="submit">Search</button>
        </div>
    </section>

    <div class="container-fluid">
        <div class="property_list_main">
            <div class="row">
                <div class="col-md-6">
                    <div id="map" class="w-100" style="height:600px"></div>
                </div>
                <div class="col-md-6">
                    <div class="property_list_info">
                        <h2>{{ __('Properties') }}</h2>
                        <div class="property_list_inr_box post-grid" id="map-property-lists">
                            <div class="col-md-9 filter-message">
                                <span class="text-secondary">{{__('Empty Properties')}}</span>
                            </div>
                            {{-- <div class="post-wrap col-lg-12 col-md-12 text-center">

                            </div> --}}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    {{-- <script src="https://unpkg.com/wrld.js@1.x.x"></script> --}}
    <link href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.0.1/leaflet.css" rel="stylesheet" />

    <script src="https://unpkg.com/@googlemaps/markerclusterer/dist/index.min.js"></script>
{{-- clusterd --}}
    <script src="https://cdn.rawgit.com/googlemaps/js-marker-clusterer/gh-pages/src/markerclusterer.js"></script>
{{-- clusterd --}}

    <script type="text/javascript">
        var limit = 4;
        var start = 0;
        var page = 1;
        var total = {{ $totalRecords }};
        var recent = 0;
        var bedroom = 0;
        var markers = []
        var gmarkers = []
        var map;
        var markerCluster;
        $('.filter-message').hide();
        // window.onload = getPropertyList("load");
        // Infinite Scrolling
        $(window).scroll(function() {
            if ($(window).scrollTop() + $(window).height() >= $(document).height() && total != recent) {
                page++;
                start = (page -1) * limit
                limit;
                var forPage = total/limit;
                var roundPage = Math.ceil(forPage);

                if(page <= roundPage)
                {
                    getPropertyList("scroll");
                }
            }
        });
        function clearFilter(type="") {

            if(markerCluster){
                markerCluster.removeMarkers(markers);
            }
                markers = [];
                page = 1;
                start = 0;
                limit = 4;
                $('#map-property-lists').html('');

            $('input[name="'+type+'"]:checked').prop("checked",false);

            getPropertyList();
        }

        function clearBedroomFilter(type="") {

            if(markerCluster){
                markerCluster.removeMarkers(markers);
            }
                markers = [];
                page = 1;
                start = 0;
                limit = 4;
                $('#map-property-lists').html('');

            var bedrooms = document.getElementsByClassName("bedroom");
            bedroom = $(".bedroom").val(null);

            getPropertyList();
        }

        function getPropertyList(type="") {

            if(type != "scroll")
            {
                page = 1;
                limit = 4;
                $('#map-property-lists').animate({scrollTop: '0px'}, 1000);
            }

// Category Filter.
            if(type == "filterClick" )
            {
                if(markerCluster){
                    markerCluster.removeMarkers(markers);
                }

                markers = [];
                page = 1;
                start = 0;
                limit = 4;
                $('#map-property-lists').html('');
            }
            $('.ajax-load').removeClass('d-none')
            var priceVal = $('#formControlRange').val();
            var localData = $('#map-property-lists').val();
            var rentSelsPrice = $('#propertyType').val();
            var propertyCondition = $('#propertyCondition').val();
            var propertyBedRoom = $('#bedroom').val();
            var propertyFloor = $('#floor').val();
            var category = $('#selectCategory').val();
            var search = $('#search').val();
            // set Two Zero after Price using toFixed(2) method:
            var selectPrice = parseFloat($('input[name="priceRange"]').val());
            var afterTwoZero = selectPrice.toFixed(2);
            var ajaxId = 1;
            // set value in inpute box (price):
            document.getElementById('textInput').value = afterTwoZero;

            $.ajax({
                type: "POST",
                url: "/list-scroll",
                dataType: 'json',
                data: {
                    "_token"            : "{{ csrf_token() }}",
                    "price"             : priceVal,
                    "localData"         : localData,
                    "ajaxId"            : ajaxId,
                    "page"              : page,
                    "rentSelsPrice"     : rentSelsPrice,
                    "category"          : category,
                    "propertyCondition" : propertyCondition,
                    "propertyFloor"     : propertyFloor,
                    "propertyBedRoom"   : propertyBedRoom,
                    "selectPrice"       : selectPrice,
                    "limit"             : limit,
                    "start"             : start,
                    "bedroom"           : bedroom,
                    "search"            : search
                },
                dataType: 'json',

                success: function(res) {
                    if (res) {
                        recent = res.records;
                        total = res.total;
                        $('.ajax-load').addClass('d-none');
                        // $('#map-property-lists').html('');
                        $('#map-property-lists').append(res.html);
                        jQuery("#page-pagination").html(res.homePagination)
                        // this is from controller to blade Pass Array:
                        if(markerCluster){
                            markerCluster.removeMarkers(markers);
                        }
                        var listPro = res.propertyList;
                        const infoWindow = new google.maps.InfoWindow({
                            content: "",
                            disableAutoPan: true,
                        });
                        let markersajax = listPro.map((propertyData, i) => {
                            if (infoWindow) infoWindow.close();
                            const marker = new google.maps.Marker({
                                position:{lat:Number(propertyData.latitude), lng:Number(propertyData.longitude)},
                                content: propertyData.name,
                            });

                            // open info window when marker is clicked
                            marker.addListener("click", () => {
                                infoWindow.setContent('<div><h4><b> '+ propertyData.name +'</b></h4></div><div><img src="/mainImage/'+ propertyData.image +'"></div>');
                                infoWindow.open(map, marker);
                                $('.property_detail_inr_info').removeClass("active");
                                $('#property'+propertyData.id).addClass("active");
                                document.getElementById('map-property-lists').getElementsByClassName('active')[0].scrollIntoView({behavior: "smooth"})
                                infoWindow.addListener('closeclick', ()=>{
                                    $('.property_detail_inr_info').removeClass('active');
                                });
                                $('.gm-ui-hover-effect').on('click', function(){
                                    $('.property_detail_inr_info').removeClass('active');
                                });
                            });
                            markers.push(marker);
                            return marker;
                        });
                        if(markers.length > 0 && map){
                            markerCluster = new MarkerClusterer(map, markers, {
                                imagePath: 'https://cdn.rawgit.com/googlemaps/js-marker-clusterer/gh-pages/images/m'
                            });
                        }
                    //
                        // listPro.forEach(function (propertyData) { .


                            // // Property id store in marker:
                            // marker.addListener('click', function () {

                            //     // Active In List Click on Marker
                            //     $('.property_detail_inr_info').removeClass("active");
                            //     $('#property'+propertyData.id).addClass("active");
                            //     // document.getElementById('#map-property-lists .active').scrollIntoView({behavior: "smooth"})

                            //     document.getElementById('map-property-lists').getElementsByClassName('active')[0].scrollIntoView({behavior: "smooth"})
                            //     infoWindow.addListener('closeclick', ()=>{
                            //         $('.property_detail_inr_info').removeClass('active');
                            //     });
                            //     $('.gm-ui-hover-effect').on('click', function(){
                            //         $('.property_detail_inr_info').removeClass('active');
                            //     });
                            // });
                            // // Multi Markers in Clusterer marker push:

                            // markers.push(marker);
                            // console.log(marker);

                            // return marker;
                        // });
                        // let cluster;
                        // if(map){
                        //     console.log(markers);
                        //     cluster = new MarkerClusterer(map, markers, {
                        //         imagePath: 'https://cdn.rawgit.com/googlemaps/js-marker-clusterer/gh-pages/images/m'
                        //     });
                        // }
                        // console.log({cluster});
                        // console.log({markersAfter:markers});
                    //
                    }
                }
            });
        }

            // $(".bedroom").click(function() {
            //     bedroom = $(this).text();
            //     $(".bedroom").removeClass('active');
            //     $(this).addClass('active');
            //     getPropertyList("filterClick");
            // });

        // function getPropertyFilter() {
            //     page = 1;
            //     limit = 4;
            //     $('#map-property-lists').animate({scrollTop: '0px'}, 1000);
            //     var rentSelsPrice = $('input[name="propertyType"]:checked').val();

            //     $('.ajax-load').removeClass('d-none')

            //     var ajaxId = 1;

            //     $.ajax({
            //         type: "POST",
            //         url: "/list-scroll",
            //         dataType: 'json',
            //         data: {
            //             "_token": "{{ csrf_token() }}",
            //             "rentSelsPrice"     : rentSelsPrice,
            //             "ajaxId": ajaxId,
            //             "page":page,
            //             "limit": limit,
            //             "start": start,
            //         },
            //         dataType: 'json',
            //         success: function(res) {
            //             if (res) {
            //                 recent = res.records;
            //                 total = res.total;
            //                 $('.ajax-load').addClass('d-none')
            //                 $('#map-property-lists').html('');
            //                 $('#map-property-lists').append(res.html);
            //                 jQuery("#page-pagination").html(res.homePagination)
            //                 // this is from controller to blade Pass Array:

            //                 if(markerCluster){
            //                     markerCluster.removeMarkers(markers);
            //                 }
            //                 var listPro = res.propertyList;
            //                 const infoWindow = new google.maps.InfoWindow({
            //                     content: "",
            //                     disableAutoPan: true,
            //                 });
            //                 markers = [];
            //                 let markersajax = listPro.map((propertyData, i) => {
            //                     if (infoWindow) infoWindow.close();
            //                     const marker = new google.maps.Marker({
            //                         position:{lat:Number(propertyData.latitude), lng:Number(propertyData.longitude)},
            //                         content: propertyData.name,
            //                     });

            //                     // open info window when marker is clicked
            //                     marker.addListener("click", () => {
            //                         infoWindow.setContent('<div><h4><b> '+ propertyData.name +'</b></h4></div><div><img src="/mainImage/'+ propertyData.image +'"></div>');
            //                         infoWindow.open(map, marker);
            //                         $('.property_detail_inr_info').removeClass("active");
            //                         $('#property'+propertyData.id).addClass("active");
            //                         document.getElementById('map-property-lists').getElementsByClassName('active')[0].scrollIntoView({behavior: "smooth"})
            //                         infoWindow.addListener('closeclick', ()=>{
            //                             $('.property_detail_inr_info').removeClass('active');
            //                         });
            //                         $('.gm-ui-hover-effect').on('click', function(){
            //                             $('.property_detail_inr_info').removeClass('active');
            //                         });
            //                     });
            //                     console.log(marker)
            //                     markers.push(marker);
            //                     return marker;
            //                 });
            //                 if(markers.length > 0 && map){
            //                     markerCluster = new MarkerClusterer(map, markers, {
            //                         imagePath: 'https://cdn.rawgit.com/googlemaps/js-marker-clusterer/gh-pages/images/m'
            //                     });
            //                 }
            //                 // listPro.forEach(function (propertyData) { .


            //                     // // Property id store in marker:
            //                     // marker.addListener('click', function () {

            //                     //     // Active In List Click on Marker
            //                     //     $('.property_detail_inr_info').removeClass("active");
            //                     //     $('#property'+propertyData.id).addClass("active");
            //                     //     // document.getElementById('#map-property-lists .active').scrollIntoView({behavior: "smooth"})

            //                     //     document.getElementById('map-property-lists').getElementsByClassName('active')[0].scrollIntoView({behavior: "smooth"})
            //                     //     infoWindow.addListener('closeclick', ()=>{
            //                     //         $('.property_detail_inr_info').removeClass('active');
            //                     //     });
            //                     //     $('.gm-ui-hover-effect').on('click', function(){
            //                     //         $('.property_detail_inr_info').removeClass('active');
            //                     //     });
            //                     // });
            //                     // // Multi Markers in Clusterer marker push:

            //                     // markers.push(marker);
            //                     // console.log(marker);

            //                     // return marker;
            //                 // });
            //                 // let cluster;
            //                 // if(map){

            //                     //     console.log(markers);
            //                     //     cluster = new MarkerClusterer(map, markers, {
            //                     //         imagePath: 'https://cdn.rawgit.com/googlemaps/js-marker-clusterer/gh-pages/images/m'
            //                     //     });
            //                 // }
            //                 // console.log({cluster});
            //                 // console.log({markersAfter:markers});
            //             }
            //         }
            //     });
        // }

        function initMap() {
            // Call Current Location Function:
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(showPosition, showError)
                    getPropertyList("load");
                } else {
                x.innerHTML = "Geolocation is not supported by this browser.";
            }
        }

        function showPosition(position) {
            return new Promise(function(resolve, reject) {
                // Get latitude ande longitude:
                lat = position.coords.latitude;
                lon = position.coords.longitude;

                if(!map){
                    map = new google.maps.Map(document.getElementById('map'), {
                        zoom: 5,
                        center: new google.maps.LatLng(lat, lon)
                    });
                    markerCluster = new MarkerClusterer(map, markers, {
                        imagePath: 'https://cdn.rawgit.com/googlemaps/js-marker-clusterer/gh-pages/images/m'
                    });
                }
                resolve({map})
            });
        }

        function showError(error) {
            switch (error.code) {
                case error.PERMISSION_DENIED:
                    // x.innerHTML = "User denied the request for Geolocation."
                    console.log("User denied the request for Geolocation.");
                    break;
                case error.POSITION_UNAVAILABLE:
                    x.innerHTML = "Location information is unavailable."
                    break;
                case error.TIMEOUT:
                    x.innerHTML = "The request to get user location timed out."
                    break;
                case error.UNKNOWN_ERROR:
                    x.innerHTML = "An unknown error occurred."
                    break;
            }
        }
        function myClick(id) {
            google.maps.event.trigger(markers[id], 'click');
        }

        $(document).ready(function(){
            $('.property_detail_inr_info').click(function(){
                $('.property_detail_inr_info').removeClass("active");
                $(this).addClass("active");
            });
        });
    </script>

    <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBsf7LHMQFIeuA_7-bR7u7EXz5CUaD6I2A&callback=initMap&v=weekly"></script>
@endsection
